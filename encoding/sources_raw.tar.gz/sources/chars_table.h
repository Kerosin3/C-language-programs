

multichar_store multichar_collection_init();

