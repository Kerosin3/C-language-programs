#ifndef __INCLUDES__
#define __INCLUDES__ 
#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <stdint.h>
#include <wctype.h>
#include "multichar.h"
#include "chars_table.h"
#define CHAR_STORE_LENGTH_MAX 70 // max alphabet 
#endif /* ifndef __INCLUDES__ */
